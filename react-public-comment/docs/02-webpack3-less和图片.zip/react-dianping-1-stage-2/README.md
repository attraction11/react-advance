## 本节内容

在 webpack3 demo 的基础上，演示如何引用 less 和内部图片

## 运行 demo

先运行`npm i --registry=https://registry.npm.taobao.org`安装所有依赖，然后再运行`npm start`可看 demo
