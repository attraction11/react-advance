## 内容

演示如何引入 css3 字体文件

## 运行 demo

先运行`npm i --registry=https://registry.npm.taobao.org`安装所有依赖，然后运行`npm start`可看 demo
