## 本章节内容

完善`webpack.production.config.js`，使程序能顺利打包

## 运行 demo

进入代码目录，先`npm i --registry=https://registry.npm.taobao.org` 安装所有的依赖包

安装完成之后，运行`npm start`即可启动页面，运行`npm run build`即可打包代码

