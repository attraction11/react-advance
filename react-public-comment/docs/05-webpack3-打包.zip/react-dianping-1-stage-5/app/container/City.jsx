import React from 'react'

class City extends React.Component {
    render() {
        return(
            <div>
                <p>City page</p>
            </div>
        )
    }
}

export default City