import React from 'react'

class NotFound extends React.Component {
    render() {
        return(
            <div>
                <p>404</p>
            </div>
        )
    }
}

export default NotFound