import React from 'react'

class Home extends React.Component {
    render() {
        return(
            <div>
                <p>Home page</p>
            </div>
        )
    }
}

export default Home