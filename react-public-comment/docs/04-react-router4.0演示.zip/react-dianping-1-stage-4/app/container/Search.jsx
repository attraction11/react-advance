import React from 'react'

class Search extends React.Component {
    render() {
        return(
            <div>
                <p>Search page</p>
            </div>
        )
    }
}

export default Search