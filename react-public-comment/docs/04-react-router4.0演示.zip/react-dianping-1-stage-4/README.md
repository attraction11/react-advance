## 内容

演示 react-router 4.0 的使用，具体可参见`app/router/RouteMap.jsx`的代码

## 运行 demo

先运行`npm i --registry=https://registry.npm.taobao.org`安装所有依赖，然后再运行`npm start`可看 demo
