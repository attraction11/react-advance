## 内容

用 webpack 3 结合 React 做一个简单的 demo

## 运行 demo

先执行`npm i --registry=https://registry.npm.taobao.org`安装所有的依赖

然后运行`npm start`可看到效果


